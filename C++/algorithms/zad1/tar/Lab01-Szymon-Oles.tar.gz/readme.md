wyniki pomiarów dla set w oparciu o vector

Dodawanie: 3948.84 s
isMember: 0.0008004 s
Union: 79.6056 s
Intersection: 295.199 s
Difference: 159.483 s

w CMakeLists są dwa projekty dla dwóch programów:
zad1 to główny (main.cpp)
zad1v2 to program do czytania z test_set i pomiarów (test.cpp)