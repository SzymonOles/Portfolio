const getMain = (req,res) => {
    res.render('informacje');
}

module.exports = {
    getMain
}